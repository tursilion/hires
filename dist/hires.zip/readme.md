19860101

I wrote this after reading about such a product in 99er magazine back in the day. I didn't use it for anything back then, but a few years ago I wrote a simple TI BASIC artillery game that used it, and that was fun to see.

The sample program shows how to use it.
